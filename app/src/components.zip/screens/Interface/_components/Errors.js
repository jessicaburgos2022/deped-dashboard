import React from "react";

export default () => {
  return (
    <React.Fragment>
      <h4>Errors</h4>
    </React.Fragment>
  );
};
